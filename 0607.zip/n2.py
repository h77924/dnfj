
if __name__  == "__main__":
    print("n2.py입니다.")
    print("__name__출력: ", __name__)

def hello2py():
    print("n2.py의 hello2py()입니다.")