#0605

#dictionary
#key- value
#carDict= {key1: value1, key2: value2, key3: value3  }
#자동차 등록번호:(생산년도, 배기량)
#1111: (2020,1600)
'''
carDict = {'h101': ('2020', '1600'),
           'h102': ('2021', '2000'),
           'b101': ('2020', '3600'),
           'b102': ('2021', '5200')}

for item in carDict.items():
    print(item[0],item[1])

print("======================")

for key in carDict.keys():
    print(key, carDict[key])

print(carDict.keys())
print(carDict.values())
print(carDict.items())
'''


#[2017, 2022, 2020, 2020, 2022]
#List appedn()
#values(), 0번째 값을 가져올수 있는가
#int로 바꿀수 있는가.
'''
yearlist = []
for value in carDict.values():
    yearlist.append(int(value[0]))
print(yearlist)

#방법1
#year = int(input("생산년도를 입력하시오")) #2020
#print(year,"년도에 생산된 자동차는", yearlist.count(2020),"대 입니다.")

#방법2
year2 = int(input("생산년도를 입력하시오")) #2020
count=0
for prod_year in yearlist:
    if prod_year == year2:
        count += 1
print(count)    
'''


#7.3 zip
#list, tuple, 문자열. 여러개를 순서대로 묶어주는것.
'''
L1 =[1,2,3,4,5]
L2 =['a','b','c','d','e']
print(list(zip(L1,L2)))
'''

#zip로 묶고,
#input을 받아서, 종목이름 입력받기.
#선수 수를 출력하는것.
#while문 돌려서 할것.
#quit을 만나면 종료할것.
#다른 종목 들어오며 몰라요 하고 다시 입려받을것.

'''
sport = ['축구','야구','농구','배구']
num = [11,9,5,6]

dictionary = dict(zip(sport,num))
while 1:
    s = input("구기종목을 입력하시오")
    if s == "quit" :
        print("quit을 입력하였다. 끝")
        break
    if s in dict.keys() :
        print("인원은", dictionary[s], "입니다.")
    else :
        print("몰라요")
        continue

    print("입력한 구기종목은", s, "이고, 인원은" , dictionary[s], "입니다.")
'''


#lambda
#filter와 lamdba를 사용하여
#리스트 [1, -2, 3, -5, 8, -3]에서 음수를 모두 제거해 보자.
'''
def positivel(x): #input -=숫자. output, 0보다 클때 참, 0보다 작을때 거짓
    return x>0
#lamdba 입력값:리턴 결과
lambda x : x>0 

#filter(함수, 리스트)
print(list(filter(positivel,[1, -2, 3, -5, 8, -3])))
print(list(filter( lambda x : x>0 ,[1, -2, 3, -5, 8, -3])))
'''

#숫자 리스트 두개를 받음.
#각각 같은 순서끼리 더하는 함수를 만들어라.
#lambda와 map을 써서 작성해라
#lambda를 쓰지 말고도 해보세요.
#결과로 이것이 나오게 하시오 [110,220,330,440,550]

'''
list3 = [10,20,30,40,50]
list4 = [100,200,300,400,500]

def mysum(n1,n2) :
    return n1+n2

lambda n1, n2: n1+n2

mysum(1,3)

print(list(map(mysum, list3, list4)))
print(list(map(mysum, [10,20,30,40,50], [100,200,300,400,500])))

print(list(map(lambda n1, n2: n1+n2, list3, list4)))
'''
