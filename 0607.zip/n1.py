#1.py
#main
import n2

n2.hello2py()
print("===========")

print("n1.py name입니다." , __name__)
print("===========")